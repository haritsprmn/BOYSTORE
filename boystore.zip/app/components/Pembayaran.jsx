"use client";

import { useEffect, useState, useRef } from "react";
import Count from "./Count";
import TimeID from "./TimeID";
import Link from "next/link";
import QRCode from "qrcode";
import Image from "next/image";
import Alert from "./Alert";
import Countdown from "./Countdown";
import { Sankofa_Display } from "next/font/google";

function Pembayaran({ data, show, onClose }) {
  const imghr = process.env.NEXT_PUBLIC_IMGHR;
  // console.log(imghr);
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [warna, setWarna] = useState(true);
  const [alertMessage, setAlertMessage] = useState("");
  const [qrSrc, setQrSrc] = useState("/blank.png");
  const [expired, setExpired] = useState(false);

  // --- Cek Status ---
  const [status, setStatus] = useState(data);

  async function cekStatus(trxid) {
    setLoading(true);

    try {
      const res = await fetch("/api/cekstatus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trxid,
        }),
      });

      const result = await res.json();
      // simpan localStorage
      localStorage.setItem("last_trx", JSON.stringify(result));
      setStatus(result);

      if (result?.pembayaran?.status === "completed") {
        console.log("ini test: " + result?.pembayaran?.status);
        window.dispatchEvent(new Event("trx-created"));
      }

      setLoading(false);
    } catch (err) {
      setWarna(false);
      setAlertMessage("Gagal cek status, coba lagi");
      setShowAlert(true);
      setLoading(false);

      // ⛔ JANGAN reload
    }
  }
  async function hapus(trxid) {
    setLoading(true);

    try {
      const res = await fetch("/api/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trxid }),
      });

      const result = await res.json();

      if (result.success === true) {
        localStorage.removeItem("last_trx");
        window.dispatchEvent(new Event("trx-deleted"));
        setVisible(false);
        onClose?.();
        return;
      }
      setWarna(false);
      setAlertMessage(result?.error || "Gagal cek status, coba lagi");
      setShowAlert(true);
    } catch (err) {
      setWarna(false);
      setAlertMessage(err.message || "Gagal cek status, coba lagi");
      setShowAlert(true);
    } finally {
      setLoading(false);
    }
  }

  const [visible, setVisible] = useState(show);

  useEffect(() => {
    if (show) setVisible(true); // trigger masuk
  }, [show, onClose]);

  const currentData = status || data;
  useEffect(() => {
    if (!currentData?.pembayaran) return;

    if (currentData.pembayaran.imgqr) {
      QRCode.toDataURL(currentData.pembayaran.imgqr, {
        width: 450,
        margin: 1,
        color: { dark: "#000", light: "#FFF" },
      })
        .then(setQrSrc)
        .catch(console.error);
    } else if (currentData.pembayaran.imgqrh) {
      setQrSrc(currentData.pembayaran.imgqrh);
    }
  }, [currentData]);

  const copyText = async (kontol) => {
    if (typeof window === "undefined") return;

    try {
      await navigator.clipboard.writeText(kontol);
      setAlertMessage(kontol + " disalin");
      setShowAlert(true);
    } catch (err) {
      alert("Gagal menyalin");
    }
  };

  const [openDetail, setOpenDetail] = useState(false);
  const [openTutorial, setOpenTutorial] = useState(false);

  const AccordionDetail = () => setOpenDetail(!openDetail);
  const AccordionTutorial = () => setOpenTutorial(!openTutorial);
  useEffect(() => {
    if (!show) return; // show = prop dari parent

    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = "";
    };
  }, [show]); // efek akan jalan setiap kali show berubah

  let Paket;
  if (data?.pesanan.durasi == 1) {
    Paket = "Harian";
  } else if (data?.pesanan.durasi == 7) {
    Paket = "Mingguan";
  } else if (data?.pesanan.durasi == 30) {
    Paket = "Bulanan";
  } else {
    Paket = "-";
  }

  const Jembot = currentData?.pembayaran?.status;

  let statusBadge = null;
  let imgBadge = null;
  let buttonBadge = null;

  if (expired) {
    buttonBadge = (
      <button
        onClick={() => hapus(currentData.pembayaran.TRXID)}
        disabled={loading}
        type="submit"
        className="w-full btn-gradient-red text-white text-center font-bold py-3.5 rounded-xl shadow-lg shadow-blue-200/50 flex items-center justify-center gap-2 transition-transform active:scale-95"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} viewBox="0 0 24 24">
          <path fill="currentColor" d="M19 4h-3.5l-1-1h-5l-1 1H5v2h14M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6z"></path>
        </svg>
        {loading ? "Memproses..." : "Hapus Transaksi"}
      </button>
    );
  } else if (Jembot === "completed") {
    buttonBadge = (
      <Link
        href={`/rating?token=${currentData?.pesanan?.token}`}
        type="submit"
        className="w-full btn-gradient-yellow text-white text-center font-bold py-3.5 rounded-xl shadow-lg shadow-blue-200/50 flex items-center justify-center gap-2 transition-transform active:scale-95"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} viewBox="0 0 24 24">
          <path fill="currentColor" d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2L9.19 8.63L2 9.24l5.46 4.73L5.82 21z"></path>
        </svg>
        Beri Penilaian
      </Link>
    );
  } else if (Jembot === "EXPIRED") {
    buttonBadge = (
      <button
        onClick={() => hapus(currentData.pembayaran.TRXID)}
        disabled={loading}
        type="submit"
        className="w-full btn-gradient-red text-white text-center font-bold py-3.5 rounded-xl shadow-lg shadow-blue-200/50 flex items-center justify-center gap-2 transition-transform active:scale-95"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} viewBox="0 0 24 24">
          <path fill="currentColor" d="M19 4h-3.5l-1-1h-5l-1 1H5v2h14M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6z"></path>
        </svg>
        {loading ? "Memproses..." : "Hapus Transaksi"}
      </button>
    );
  } else if (Jembot === "pending") {
    buttonBadge = (
      <button
        onClick={() => cekStatus(currentData.pembayaran.TRXID)}
        disabled={loading}
        type="submit"
        className="w-full btn-gradient text-white text-center font-bold py-3.5 rounded-xl shadow-lg shadow-blue-200/50 flex items-center justify-center gap-2 transition-transform active:scale-95"
      >
        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" data-icon="solar:refresh-circle-bold" className="iconify text-xl iconify--solar">
          <path
            fill="currentColor"
            fillRule="evenodd"
            d="M22 12c0 5.523-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2s10 4.477 10 10m-16.54-.917a6.59 6.59 0 0 1 6.55-5.833a6.59 6.59 0 0 1 5.242 2.592a.75.75 0 0 1-1.192.911a5.09 5.09 0 0 0-4.05-2.003a5.09 5.09 0 0 0-5.037 4.333h.364a.75.75 0 0 1 .53 1.281l-1.169 1.167a.75.75 0 0 1-1.06 0L4.47 12.364a.75.75 0 0 1 .53-1.28zm12.902-.614a.75.75 0 0 0-1.06 0l-1.168 1.167a.75.75 0 0 0 .53 1.28h.363a5.09 5.09 0 0 1-5.036 4.334a5.08 5.08 0 0 1-4.038-1.986a.75.75 0 0 0-1.188.916a6.58 6.58 0 0 0 5.226 2.57a6.59 6.59 0 0 0 6.549-5.833H19a.75.75 0 0 0 .53-1.281z"
            clipRule="evenodd"
          ></path>
        </svg>
        {loading ? "Memproses..." : "Cek Status Pembayaran"}
      </button>
    );
  }

  if (expired) {
    imgBadge = <Image src={imghr} alt="QR Pembayaran" width={192} height={192} className="object-contain rounded-lg mx-auto" />;
  } else {
    imgBadge = <Image src={qrSrc} alt="QR Pembayaran" width={192} height={192} className="object-contain rounded-lg mx-auto" />;
  }

  if (expired) {
    statusBadge = <span className="text-xs text-red-500 font-bold bg-red-50 px-2 py-1 rounded-md">EXPIRED</span>;
  } else if (Jembot === "completed") {
    statusBadge = <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2 py-1 rounded-md">COMPLETED</span>;
  } else if (Jembot === "EXPIRED") {
    statusBadge = <span className="text-xs text-red-500 font-bold bg-red-50 px-2 py-1 rounded-md">EXPIRED</span>;
  } else if (Jembot === "pending") {
    statusBadge = <span className="text-xs text-amber-500 font-bold bg-amber-50 px-2 py-1 rounded-md">PENDING</span>;
  }

  if (!visible) return null;

  return (
    <>
      <div className="fixed inset-0 z-50">
        {/* BACKDROP (TIDAK IKUT SCROLL) */}
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in"></div>

        {/* WRAPPER SCROLL */}
        <div className="relative z-10 flex min-h-screen items-center justify-center px-4 overflow-y-auto">
          {/* MODAL */}
          <div className="relative bg-white w-full max-w-md max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl animate-scale-in">
            <div className="bg-slate-50 p-6 text-center border-b border-slate-100">
              <h2 className="text-xl font-bold text-slate-800 flex items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" data-icon="solar:wallet-money-bold-duotone" className="iconify text-blue-600 iconify--solar">
                  <path fill="currentColor" d="M4.892 9.614c0-.402.323-.728.722-.728H9.47c.4 0 .723.326.723.728a.726.726 0 0 1-.723.729H5.614a.726.726 0 0 1-.722-.729"></path>
                  <path
                    fill="currentColor"
                    fillRule="evenodd"
                    d="M21.188 10.004q-.094-.005-.2-.004h-2.773C15.944 10 14 11.736 14 14s1.944 4 4.215 4h2.773q.106.001.2-.004c.923-.056 1.739-.757 1.808-1.737c.004-.064.004-.133.004-.197v-4.124c0-.064 0-.133-.004-.197c-.069-.98-.885-1.68-1.808-1.737m-3.217 5.063c.584 0 1.058-.478 1.058-1.067c0-.59-.474-1.067-1.058-1.067s-1.06.478-1.06 1.067c0 .59.475 1.067 1.06 1.067"
                    clipRule="evenodd"
                  ></path>
                  <path
                    fill="currentColor"
                    d="M21.14 10.002c0-1.181-.044-2.448-.798-3.355a4 4 0 0 0-.233-.256c-.749-.748-1.698-1.08-2.87-1.238C16.099 5 14.644 5 12.806 5h-2.112C8.856 5 7.4 5 6.26 5.153c-1.172.158-2.121.49-2.87 1.238c-.748.749-1.08 1.698-1.238 2.87C2 10.401 2 11.856 2 13.694v.112c0 1.838 0 3.294.153 4.433c.158 1.172.49 2.121 1.238 2.87c.749.748 1.698 1.08 2.87 1.238c1.14.153 2.595.153 4.433.153h2.112c1.838 0 3.294 0 4.433-.153c1.172-.158 2.121-.49 2.87-1.238q.305-.308.526-.66c.45-.72.504-1.602.504-2.45l-.15.001h-2.774C15.944 18 14 16.264 14 14s1.944-4 4.215-4h2.773q.079 0 .151.002"
                    opacity=".5"
                  ></path>
                  <path fill="currentColor" d="M10.101 2.572L8 3.992l-1.733 1.16C7.405 5 8.859 5 10.694 5h2.112c1.838 0 3.294 0 4.433.153q.344.045.662.114L16 4l-2.113-1.428a3.42 3.42 0 0 0-3.786 0"></path>
                </svg>
                Pembayaran
              </h2>
              <p className="text-slate-500 text-xs mt-1 font-medium">Selesaikan pembayaran sebelum waktu habis</p>
              <button
                onClick={() => {
                  setVisible(false);
                  onClose?.();
                }}
                className="absolute top-5 right-5 z-50 text-slate-400 hover:text-red-500 transition text-xl"
                aria-label="Tutup"
              >
                ✖
              </button>
            </div>

            <div className="p-6 flex flex-col items-center">
              {currentData?.pembayaran?.status == "completed" && (
                <div className="w-full mb-4 bg-emerald-50 text-emerald-600 px-4 py-2 rounded-lg text-sm font-medium flex justify-between items-center border border-emerald-100 shadow-sm">
                  <span className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} viewBox="0 0 24 24">
                      <path fill="currentColor" d="M23 12c0 6.075-4.925 11-11 11S1 18.075 1 12S5.925 1 12 1s11 4.925 11 11M9.305 18.11l9.402-9.403l-1.414-1.414l-7.883 7.883l-2.476-3.01l-1.511 1.31l3.882 4.633z"></path>
                    </svg>{" "}
                    Masa Aktif
                  </span>
                  <span id="countdown" className="font-bold font-mono text-base">
                    <TimeID ts={currentData.expired} />
                  </span>
                </div>
              )}
              {currentData?.pembayaran?.status != "completed" && (
                <div className="w-full mb-4 bg-red-50 text-red-600 px-4 py-2 rounded-lg text-sm font-medium flex justify-between items-center border border-red-100 shadow-sm">
                  <span className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} viewBox="0 0 24 24">
                      <path fill="currentColor" d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,20a9,9,0,1,1,9-9A9,9,0,0,1,12,21Z"></path>
                      <rect width={2} height={7} x={11} y={6} fill="currentColor" rx={1}>
                        <animateTransform attributeName="transform" dur="9s" repeatCount="indefinite" type="rotate" values="0 12 12;360 12 12"></animateTransform>
                      </rect>
                      <rect width={2} height={9} x={11} y={11} fill="currentColor" rx={1}>
                        <animateTransform attributeName="transform" dur="0.75s" repeatCount="indefinite" type="rotate" values="0 12 12;360 12 12"></animateTransform>
                      </rect>
                    </svg>{" "}
                    Selesaikan dalam
                  </span>
                  <span id="countdown" className="font-bold font-mono text-base">
                    {/* <Count targetTime={currentData.pembayaran.expired} onExpire={() => setExpired(true)} /> */}
                    <Countdown
                      targetTime={currentData.pembayaran.expired}
                      onExpire={() => {
                        setExpired(true);
                        console.log("EXPIRED DIPANGGIL: " + expired);
                      }}
                    />
                  </span>
                </div>
              )}

              {/* <!-- QR Code Frame --> */}
              <div className="relative p-4 bg-white rounded-2xl border-2 border-dashed border-blue-400 shadow-sm mb-6 group hover:border-slate-200 transition-colors">
                {imgBadge}
                {/* <Image src={qrSrc} alt="QR Pembayaran" width={192} height={192} className="object-contain rounded-lg mx-auto" /> */}
                <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-white px-3 py-1 rounded-full border border-blue-400 shadow-sm flex items-center gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" data-icon="solar:qr-code-bold" className="iconify text-slate-900 iconify--solar">
                    <path
                      fill="currentColor"
                      fillRule="evenodd"
                      d="M16.525 2h.068c.884 0 1.597 0 2.17.055c.592.056 1.108.175 1.571.459c.47.288.864.682 1.152 1.152c.284.463.403.979.46 1.57C22 5.81 22 6.524 22 7.407v.07c0 .58 0 1.064-.037 1.458c-.04.412-.124.795-.34 1.147c-.21.344-.5.633-.844.844c-.352.216-.736.3-1.147.34c-.394.037-.879.037-1.46.037h-1.104c-.836 0-1.533 0-2.086-.074c-.584-.079-1.111-.251-1.535-.675s-.596-.95-.675-1.535c-.074-.553-.074-1.25-.074-2.086V5.827c0-.58 0-1.065.037-1.459c.04-.411.124-.795.34-1.146c.21-.345.5-.634.844-.845c.352-.216.735-.3 1.147-.34C15.459 2 15.944 2 16.525 2m.824 5.814c-.48 0-.72 0-.889-.12a.7.7 0 0 1-.154-.154c-.12-.17-.12-.41-.12-.889s0-.719.12-.888a.7.7 0 0 1 .154-.155c.17-.12.41-.12.889-.12s.719 0 .888.12q.09.065.155.155c.12.169.12.409.12.888s0 .72-.12.889a.7.7 0 0 1-.155.154c-.169.12-.409.12-.888.12M10.08 2.377c-.35-.216-.734-.3-1.146-.34C8.54 2 8.056 2 7.475 2h-.068c-.884 0-1.597 0-2.17.055c-.592.056-1.108.175-1.571.459c-.47.288-.864.682-1.152 1.152c-.284.463-.403.979-.46 1.57C2 5.81 2 6.524 2 7.407v.07c0 .58 0 1.064.037 1.458c.04.412.124.795.34 1.147c.21.344.5.633.845.844c.351.216.735.3 1.146.34c.394.037.878.037 1.46.037h1.104c.836 0 1.533 0 2.086-.074c.584-.079 1.111-.251 1.535-.675s.596-.95.675-1.535c.074-.553.074-1.25.074-2.086V5.827c0-.58 0-1.065-.037-1.459c-.04-.411-.124-.795-.34-1.146a2.56 2.56 0 0 0-.844-.845M5.764 7.694c.169.12.409.12.888.12s.72 0 .889-.12a.7.7 0 0 0 .154-.154c.12-.17.12-.41.12-.889s0-.719-.12-.888a.7.7 0 0 0-.154-.155c-.17-.12-.41-.12-.889-.12s-.719 0-.888.12a.7.7 0 0 0-.155.155c-.12.169-.12.409-.12.888s0 .72.12.889a.7.7 0 0 0 .155.154m3.254 5.078c.584.079 1.111.251 1.535.675s.596.95.675 1.535c.074.553.074 1.25.074 2.086v1.105c0 .58 0 1.065-.037 1.459c-.04.411-.124.795-.34 1.146c-.21.345-.5.634-.844.845c-.352.216-.735.3-1.147.34C8.54 22 8.056 22 7.475 22h-.068c-.884 0-1.597 0-2.17-.055c-.592-.056-1.108-.175-1.571-.459a3.5 3.5 0 0 1-1.152-1.152c-.284-.463-.403-.979-.46-1.57C2 18.19 2 17.477 2 16.594v-.07c0-.58 0-1.065.037-1.458c.04-.412.124-.795.34-1.147c.21-.344.5-.633.845-.844c.351-.216.735-.3 1.146-.34c.394-.037.878-.037 1.46-.037h1.104c.836 0 1.533 0 2.086.074m-2.367 5.74c-.48 0-.719 0-.888-.12a.7.7 0 0 1-.155-.155c-.12-.169-.12-.409-.12-.888s0-.72.12-.889a.7.7 0 0 1 .155-.154c.169-.12.409-.12.888-.12s.72 0 .889.12q.09.065.154.154c.12.17.12.41.12.889s0 .719-.12.888a.7.7 0 0 1-.154.155c-.17.12-.41.12-.889.12"
                      clipRule="evenodd"
                    ></path>
                    <path
                      fill="currentColor"
                      d="M12.698 16.616v.035h1.395c0-.668 0-1.116.036-1.458c.033-.33.093-.482.16-.583a1.2 1.2 0 0 1 .32-.321c.102-.067.254-.127.584-.16c.342-.035.79-.036 1.458-.036h1.86v-1.395h-1.895c-.623 0-1.143 0-1.564.042c-.44.045-.849.143-1.217.389c-.28.186-.52.426-.706.706c-.246.368-.344.777-.389 1.217c-.042.42-.042.94-.042 1.564M22 18.535v-.023h-1.395c0 .443 0 .74-.016.97c-.016.224-.043.333-.073.405a1.16 1.16 0 0 1-.63.63c-.07.029-.18.056-.404.072c-.23.015-.527.016-.97.016h-1.86V22h1.883c.414 0 .759 0 1.042-.02a2.6 2.6 0 0 0 .844-.175a2.56 2.56 0 0 0 1.384-1.384c.112-.27.156-.549.176-.844c.019-.283.019-.628.019-1.042m-7.907 2.767a.698.698 0 1 1-1.395 0v-2.79h1.395zm7.209-8.604a.7.7 0 0 0-.697.697v3.256H22v-3.256a.7.7 0 0 0-.698-.697m-5.226 3.919c-.076.184-.076.417-.076.883s0 .699.076.883a1 1 0 0 0 .541.54c.184.077.417.077.883.077s.699 0 .883-.076a1 1 0 0 0 .54-.541c.077-.184.077-.417.077-.883s0-.699-.076-.883a1 1 0 0 0-.541-.54C18.199 16 17.966 16 17.5 16s-.699 0-.883.076a1 1 0 0 0-.54.541"
                    ></path>
                  </svg>
                  <span className="text-[10px] font-bold text-slate-600">SCAN QRIS</span>
                </div>
              </div>

              {/* <!-- Transaction Details --> */}
              <div className="w-full bg-slate-50/80 rounded-2xl p-5 space-y-4 mb-6 border border-slate-100">
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 text-xs font-semibold uppercase">Total Tagihan</span>
                  <span className="text-xl font-extrabold text-slate-800">
                    Rp
                    {data ? data.pembayaran.harga.toLocaleString("id-ID") : "0"}
                  </span>
                </div>
                <div className="h-px bg-slate-200/60 w-full"></div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 text-xs">ID Transaksi</span>
                    <div className="flex items-center gap-2 bg-white px-2 py-1 rounded-lg border border-slate-100">
                      <span className="font-mono text-xs font-bold text-slate-700 select-all">{data ? data.pembayaran.TRXID : ""}</span>
                      <button onClick={() => copyText(data.pembayaran.TRXID)} className="text-slate-400 hover:text-blue-600 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" data-icon="solar:copy-bold" className="iconify iconify--solar">
                          <path
                            fill="currentColor"
                            d="M15.24 2h-3.894c-1.764 0-3.162 0-4.255.148c-1.126.152-2.037.472-2.755 1.193c-.719.721-1.038 1.636-1.189 2.766C3 7.205 3 8.608 3 10.379v5.838c0 1.508.92 2.8 2.227 3.342c-.067-.91-.067-2.185-.067-3.247v-5.01c0-1.281 0-2.386.118-3.27c.127-.948.413-1.856 1.147-2.593s1.639-1.024 2.583-1.152c.88-.118 1.98-.118 3.257-.118h3.07c1.276 0 2.374 0 3.255.118A3.6 3.6 0 0 0 15.24 2"
                          ></path>
                          <path
                            fill="currentColor"
                            d="M6.6 11.397c0-2.726 0-4.089.844-4.936c.843-.847 2.2-.847 4.916-.847h2.88c2.715 0 4.073 0 4.917.847S21 8.671 21 11.397v4.82c0 2.726 0 4.089-.843 4.936c-.844.847-2.202.847-4.917.847h-2.88c-2.715 0-4.073 0-4.916-.847c-.844-.847-.844-2.21-.844-4.936z"
                          ></path>
                        </svg>
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 text-xs">Status</span>
                    {statusBadge}
                  </div>
                </div>
              </div>

              {/* <!-- Action Buttons --> */}
              <div className="w-full space-y-3">
                {buttonBadge}
                <Link
                  href={`/detail?trx=${currentData.pembayaran.TRXID}`}
                  className="w-full bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-blue-600 hover:border-blue-200 text-center font-bold py-3.5 rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" data-icon="solar:link-circle-bold" className="iconify text-lg iconify--solar">
                    <path
                      fill="currentColor"
                      fillRule="evenodd"
                      d="M3.464 20.536C4.93 22 7.286 22 12 22s7.071 0 8.535-1.465C22 19.072 22 16.714 22 12s0-7.071-1.465-8.536C19.072 2 16.714 2 12 2S4.929 2 3.464 3.464C2 4.93 2 7.286 2 12s0 7.071 1.464 8.535M9.5 8.75A3.25 3.25 0 1 0 12.75 12a.75.75 0 0 1 1.5 0A4.75 4.75 0 1 1 9.5 7.25a.75.75 0 0 1 0 1.5M17.75 12a3.25 3.25 0 0 1-3.25 3.25a.75.75 0 0 0 0 1.5A4.75 4.75 0 1 0 9.75 12a.75.75 0 0 0 1.5 0a3.25 3.25 0 0 1 6.5 0"
                      clipRule="evenodd"
                    ></path>
                  </svg>
                  Buka Detail Pesanan
                </Link>
              </div>
              <div className="w-full mt-4 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <button
                  onClick={AccordionDetail} // ✅ React style
                  className="w-full px-5 py-3 flex justify-between items-center bg-white hover:bg-slate-50 transition"
                >
                  <span className="text-sm font-semibold text-slate-700">Rincian Pesanan</span>
                  <iconify-icon icon="heroicons:chevron-down" className="text-slate-400 transition-transform" style={{ transform: openDetail ? "rotate(180deg)" : "rotate(0deg)" }} />
                </button>

                <div className={`border-t border-slate-100 bg-slate-50/50 p-5 text-sm ${openDetail ? "block" : "hidden"}`}>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-500">WhatsApp</span>
                    <span className="font-medium text-slate-800">{currentData ? currentData.pesanan.wa : "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-500">Cookie</span>
                    <span className="font-medium text-slate-800 text-right">{currentData ? currentData.pesanan.cookietext : "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-500">Paket</span>
                    <span className="font-medium text-slate-800">{Paket}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-200">
                    <span className="font-bold text-slate-700">Token</span>

                    <div className="flex items-center gap-2">
                      <span className="font-bold gradient-text">{currentData ? currentData.pesanan.token : "-"}</span>

                      <button onClick={() => copyText(currentData.pesanan.token)} className="text-slate-400 hover:text-blue-600 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" data-icon="solar:copy-bold" className="iconify iconify--solar">
                          <path
                            fill="currentColor"
                            d="M15.24 2h-3.894c-1.764 0-3.162 0-4.255.148c-1.126.152-2.037.472-2.755 1.193c-.719.721-1.038 1.636-1.189 2.766C3 7.205 3 8.608 3 10.379v5.838c0 1.508.92 2.8 2.227 3.342c-.067-.91-.067-2.185-.067-3.247v-5.01c0-1.281 0-2.386.118-3.27c.127-.948.413-1.856 1.147-2.593s1.639-1.024 2.583-1.152c.88-.118 1.98-.118 3.257-.118h3.07c1.276 0 2.374 0 3.255.118A3.6 3.6 0 0 0 15.24 2"
                          ></path>
                          <path
                            fill="currentColor"
                            d="M6.6 11.397c0-2.726 0-4.089.844-4.936c.843-.847 2.2-.847 4.916-.847h2.88c2.715 0 4.073 0 4.917.847S21 8.671 21 11.397v4.82c0 2.726 0 4.089-.843 4.936c-.844.847-2.202.847-4.917.847h-2.88c-2.715 0-4.073 0-4.916-.847c-.844-.847-.844-2.21-.844-4.936z"
                          ></path>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 w-full bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <button onClick={AccordionTutorial} className="w-full px-5 py-3 flex justify-between items-center bg-white hover:bg-slate-50 transition">
                  <span className="text-sm font-semibold text-slate-700">Cara Pembayaran</span>
                  <iconify-icon id="icon-guide" icon="heroicons:chevron-down" className="text-slate-400 transition-transform" style={{ transform: openTutorial ? "rotate(180deg)" : "rotate(0deg)" }}></iconify-icon>
                </button>
                <div id="guide-details" className={`border-t border-slate-100 bg-slate-50/50 p-5 text-sm text-slate-600 space-y-3 ${openTutorial ? "block" : "hidden"}`}>
                  <div className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-xs">1</span>
                    <p>Buka aplikasi e-wallet (GoPay, OVO, Dana, LinkAja, ShopeePay) atau Mobile Banking (BCA, Mandiri, BRI, dll).</p>
                  </div>
                  <div className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-xs">2</span>
                    <p>
                      Pilih menu <strong>Scan QRIS</strong>.
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-xs">3</span>
                    <p>Arahkan kamera ke kode QR di atas.</p>
                  </div>
                  <div className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-xs">4</span>
                    <p>
                      Periksa nama merchant <strong className="text-slate-800">PAKASIR</strong> dan total bayar.
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-xs">5</span>
                    <p>Masukkan PIN Anda dan pembayaran selesai.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Alert show={showAlert} warna={warna} onClose={() => setShowAlert(false)} message={alertMessage} />
    </>
  );
}

export default Pembayaran;
